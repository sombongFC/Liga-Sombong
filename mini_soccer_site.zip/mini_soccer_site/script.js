/*
 * Mini Soccer League script
 *
 * This script powers the interactive league table and schedule. It allows you to
 * rename teams, enter match results (normal time scores and penalty shootout
 * winners), and automatically calculates the standings using the custom points
 * system described on the page. Results and team names are persisted in
 * localStorage so they remain when you refresh the page.
 */

document.addEventListener('DOMContentLoaded', () => {
  // Load teams from localStorage or fallback to defaults
  let teams = loadTeams();

  // Generate or load matches
  let matches = loadMatches(teams);

  // Render team name inputs
  renderTeamInputs(teams, (updatedTeams) => {
    teams = updatedTeams;
    saveTeams(teams);
    // When team names change, update match names in UI and standings
    updateMatchLabels(teams);
    updateStandings(teams, matches);
  });

  // Render matches table
  renderMatchesTable(teams, matches, () => {
    // On change callback: persist matches and update standings
    saveMatches(matches);
    updateStandings(teams, matches);
  });

  // Compute initial standings
  updateStandings(teams, matches);
});

/**
 * Load teams from localStorage or return default names if none stored.
 *
 * @returns {string[]}
 */
function loadTeams() {
  try {
    const stored = localStorage.getItem('miniSoccerTeams');
    if (stored) {
      const parsed = JSON.parse(stored);
      if (Array.isArray(parsed) && parsed.length >= 3) {
        return parsed.slice(0, 3);
      }
    }
  } catch (e) {
    // ignore parse errors
  }
  return ['Team 1', 'Team 2', 'Team 3'];
}

/**
 * Save teams to localStorage.
 * @param {string[]} teams
 */
function saveTeams(teams) {
  try {
    localStorage.setItem('miniSoccerTeams', JSON.stringify(teams));
  } catch (e) {
    // Ignore quota errors
  }
}

/**
 * Load matches from localStorage or create new schedule for 3 teams (home & away).
 * @param {string[]} teams
 * @returns {Array}
 */
function loadMatches(teams) {
  try {
    const stored = localStorage.getItem('miniSoccerMatches');
    if (stored) {
      const parsed = JSON.parse(stored);
      if (Array.isArray(parsed)) {
        // Ensure matches length matches schedule (should be 6 for 3 teams)
        if (parsed.length === 6) {
          return parsed;
        }
      }
    }
  } catch (e) {
    // ignore parse errors
  }
  // Create new schedule: each pair plays twice (home and away)
  const newMatches = [];
  let matchId = 1;
  for (let i = 0; i < teams.length; i++) {
    for (let j = i + 1; j < teams.length; j++) {
      // First leg: i home, j away
      newMatches.push({
        id: matchId++,
        homeTeam: i,
        awayTeam: j,
        homeGoals: null,
        awayGoals: null,
        penaltyWinner: null
      });
      // Second leg: j home, i away
      newMatches.push({
        id: matchId++,
        homeTeam: j,
        awayTeam: i,
        homeGoals: null,
        awayGoals: null,
        penaltyWinner: null
      });
    }
  }
  return newMatches;
}

/**
 * Save matches to localStorage
 * @param {Array} matches
 */
function saveMatches(matches) {
  try {
    localStorage.setItem('miniSoccerMatches', JSON.stringify(matches));
  } catch (e) {
    // ignore
  }
}

/**
 * Render the team name input fields and attach listeners to update names.
 * @param {string[]} teams
 * @param {Function} onUpdate callback receives updated teams array
 */
function renderTeamInputs(teams, onUpdate) {
  const container = document.querySelector('.teams-inputs');
  container.innerHTML = '';
  teams.forEach((name, idx) => {
    const label = document.createElement('label');
    label.innerHTML = `Team ${idx + 1}: `;
    const input = document.createElement('input');
    input.type = 'text';
    input.value = name;
    input.id = `team-name-${idx}`;
    input.addEventListener('input', () => {
      teams[idx] = input.value || `Team ${idx + 1}`;
      onUpdate([...teams]);
    });
    label.appendChild(input);
    container.appendChild(label);
  });
}

/**
 * Update team names displayed in matches table after renaming.
 * @param {string[]} teams
 */
function updateMatchLabels(teams) {
  const matchRows = document.querySelectorAll('#matches-table tbody tr');
  matchRows.forEach((row) => {
    const homeIdx = parseInt(row.getAttribute('data-home'), 10);
    const awayIdx = parseInt(row.getAttribute('data-away'), 10);
    row.querySelector('.home-name').textContent = teams[homeIdx];
    row.querySelector('.away-name').textContent = teams[awayIdx];
    // Update penalty select options
    const penSelect = row.querySelector('.penalty-select');
    if (penSelect) {
      penSelect.options[1].text = teams[homeIdx];
      penSelect.options[1].value = homeIdx.toString();
      penSelect.options[2].text = teams[awayIdx];
      penSelect.options[2].value = awayIdx.toString();
    }
  });
  // Also update standings header names if needed
  updateStandings(teams, loadMatches(teams));
}

/**
 * Render matches table with input fields. Attaches event listeners to update match data.
 * @param {string[]} teams
 * @param {Array} matches
 * @param {Function} onChange callback invoked whenever a match result is updated
 */
function renderMatchesTable(teams, matches, onChange) {
  const tbody = document.querySelector('#matches-table tbody');
  tbody.innerHTML = '';
  matches.forEach((match, idx) => {
    const tr = document.createElement('tr');
    tr.setAttribute('data-idx', idx.toString());
    tr.setAttribute('data-home', match.homeTeam);
    tr.setAttribute('data-away', match.awayTeam);

    // Match number
    const tdNum = document.createElement('td');
    tdNum.textContent = (idx + 1).toString();
    tr.appendChild(tdNum);

    // Home team name
    const tdHome = document.createElement('td');
    tdHome.className = 'home-name';
    tdHome.textContent = teams[match.homeTeam];
    tr.appendChild(tdHome);

    // vs separator
    const tdVs = document.createElement('td');
    tdVs.textContent = 'vs';
    tr.appendChild(tdVs);

    // Away team name
    const tdAway = document.createElement('td');
    tdAway.className = 'away-name';
    tdAway.textContent = teams[match.awayTeam];
    tr.appendChild(tdAway);

    // Home goals input
    const tdHomeGoals = document.createElement('td');
    const inputHome = document.createElement('input');
    inputHome.type = 'number';
    inputHome.min = '0';
    inputHome.step = '1';
    inputHome.placeholder = '-';
    if (match.homeGoals !== null && match.homeGoals !== undefined) {
      inputHome.value = match.homeGoals;
    }
    inputHome.addEventListener('input', () => {
      const val = inputHome.value;
      match.homeGoals = val === '' ? null : parseInt(val, 10);
      // Reset penalty if scores are not equal
      if (match.homeGoals !== null && match.awayGoals !== null && match.homeGoals !== match.awayGoals) {
        match.penaltyWinner = null;
        const penSelect = tr.querySelector('.penalty-select');
        if (penSelect) penSelect.value = '';
      }
      onChange();
    });
    tdHomeGoals.appendChild(inputHome);
    tr.appendChild(tdHomeGoals);

    // Away goals input
    const tdAwayGoals = document.createElement('td');
    const inputAway = document.createElement('input');
    inputAway.type = 'number';
    inputAway.min = '0';
    inputAway.step = '1';
    inputAway.placeholder = '-';
    if (match.awayGoals !== null && match.awayGoals !== undefined) {
      inputAway.value = match.awayGoals;
    }
    inputAway.addEventListener('input', () => {
      const val = inputAway.value;
      match.awayGoals = val === '' ? null : parseInt(val, 10);
      // Reset penalty if scores are not equal
      if (match.homeGoals !== null && match.awayGoals !== null && match.homeGoals !== match.awayGoals) {
        match.penaltyWinner = null;
        const penSelect = tr.querySelector('.penalty-select');
        if (penSelect) penSelect.value = '';
      }
      onChange();
    });
    tdAwayGoals.appendChild(inputAway);
    tr.appendChild(tdAwayGoals);

    // Penalty winner select
    const tdPenalty = document.createElement('td');
    const select = document.createElement('select');
    select.className = 'penalty-select';
    // Default empty option
    const optionEmpty = document.createElement('option');
    optionEmpty.value = '';
    optionEmpty.textContent = '-';
    select.appendChild(optionEmpty);
    // Home team option
    const optionHome = document.createElement('option');
    optionHome.value = match.homeTeam.toString();
    optionHome.textContent = teams[match.homeTeam];
    select.appendChild(optionHome);
    // Away team option
    const optionAway = document.createElement('option');
    optionAway.value = match.awayTeam.toString();
    optionAway.textContent = teams[match.awayTeam];
    select.appendChild(optionAway);
    // Set selected value if exists
    if (match.penaltyWinner !== null && match.penaltyWinner !== undefined) {
      select.value = match.penaltyWinner.toString();
    }
    select.addEventListener('change', () => {
      // Only allow penalty winner if match is a draw
      const homeGoals = match.homeGoals;
      const awayGoals = match.awayGoals;
      if (homeGoals !== null && awayGoals !== null && homeGoals === awayGoals) {
        match.penaltyWinner = select.value === '' ? null : parseInt(select.value, 10);
      } else {
        // Reset selection if scores are not equal
        select.value = '';
        match.penaltyWinner = null;
      }
      onChange();
    });
    tdPenalty.appendChild(select);
    tr.appendChild(tdPenalty);

    tbody.appendChild(tr);
  });
}

/**
 * Compute standings and update the standings table.
 * @param {string[]} teams
 * @param {Array} matches
 */
function updateStandings(teams, matches) {
  const stats = teams.map(() => ({
    P: 0, // played
    Wn: 0, // normal wins
    Pw: 0, // penalty wins
    Pl: 0, // penalty losses
    Ln: 0, // normal losses
    GF: 0, // goals for
    GA: 0, // goals against
    GD: 0, // goal difference
    Pts: 0
  }));

  // Compute stats for each match
  matches.forEach((m) => {
    if (m.homeGoals === null || m.awayGoals === null) return; // incomplete

    const home = m.homeTeam;
    const away = m.awayTeam;
    const hg = m.homeGoals;
    const ag = m.awayGoals;

    // update played and goals
    stats[home].P++;
    stats[away].P++;
    stats[home].GF += hg;
    stats[home].GA += ag;
    stats[away].GF += ag;
    stats[away].GA += hg;

    if (hg > ag) {
      // home win normal
      stats[home].Wn++;
      stats[home].Pts += 3;
      stats[away].Ln++;
      // no points for away
    } else if (hg < ag) {
      // away win normal
      stats[away].Wn++;
      stats[away].Pts += 3;
      stats[home].Ln++;
    } else {
      // draw - decide by penalties
      if (m.penaltyWinner === home) {
        // home wins penalties
        stats[home].Pw++;
        stats[home].Pts += 2;
        stats[away].Pl++;
        stats[away].Pts += 1;
      } else if (m.penaltyWinner === away) {
        stats[away].Pw++;
        stats[away].Pts += 2;
        stats[home].Pl++;
        stats[home].Pts += 1;
      } else {
        // Penalty not decided; treat as draw with zero points? default: both get 0
        // This case should not happen ideally, but we handle gracefully.
      }
    }
  });
  // compute GD
  stats.forEach((s) => {
    s.GD = s.GF - s.GA;
  });

  // Prepare array for sorting
  const teamIndices = teams.map((_, i) => i);
  teamIndices.sort((a, b) => compareTeams(a, b, stats, matches));

  // Render standings table
  const tbody = document.querySelector('#standings-table tbody');
  tbody.innerHTML = '';
  teamIndices.forEach((teamIdx, pos) => {
    const s = stats[teamIdx];
    const tr = document.createElement('tr');
    // Position
    const tdPos = document.createElement('td');
    tdPos.textContent = (pos + 1).toString();
    tr.appendChild(tdPos);
    // Team name
    const tdName = document.createElement('td');
    tdName.textContent = teams[teamIdx];
    tr.appendChild(tdName);
    // Played
    const tdP = document.createElement('td');
    tdP.textContent = s.P.toString();
    tr.appendChild(tdP);
    // Wn
    const tdWn = document.createElement('td');
    tdWn.textContent = s.Wn.toString();
    tr.appendChild(tdWn);
    // Pw
    const tdPw = document.createElement('td');
    tdPw.textContent = s.Pw.toString();
    tr.appendChild(tdPw);
    // Pl
    const tdPl = document.createElement('td');
    tdPl.textContent = s.Pl.toString();
    tr.appendChild(tdPl);
    // Ln
    const tdLn = document.createElement('td');
    tdLn.textContent = s.Ln.toString();
    tr.appendChild(tdLn);
    // GF
    const tdGF = document.createElement('td');
    tdGF.textContent = s.GF.toString();
    tr.appendChild(tdGF);
    // GA
    const tdGA = document.createElement('td');
    tdGA.textContent = s.GA.toString();
    tr.appendChild(tdGA);
    // GD
    const tdGD = document.createElement('td');
    tdGD.textContent = s.GD.toString();
    tr.appendChild(tdGD);
    // Points
    const tdPts = document.createElement('td');
    tdPts.textContent = s.Pts.toString();
    tr.appendChild(tdPts);
    tbody.appendChild(tr);
  });
}

/**
 * Comparison function for sorting teams based on points, head‑to‑head, goal difference, goals for, and name.
 * Returns negative if a should come before b.
 * @param {number} a index of team a
 * @param {number} b index of team b
 * @param {Array} stats array of team stats
 * @param {Array} matches
 */
function compareTeams(a, b, stats, matches) {
  // 1. Total points
  if (stats[a].Pts !== stats[b].Pts) {
    return stats[b].Pts - stats[a].Pts;
  }
  // 2. Head‑to‑head points
  const htpA = getHeadToHeadPoints(a, b, matches);
  const htpB = getHeadToHeadPoints(b, a, matches);
  if (htpA !== htpB) {
    return htpB - htpA;
  }
  // 3. Head‑to‑head goal difference
  const htgA = getHeadToHeadGoalDiff(a, b, matches);
  const htgB = getHeadToHeadGoalDiff(b, a, matches);
  if (htgA !== htgB) {
    return htgB - htgA;
  }
  // 4. Overall goal difference
  if (stats[a].GD !== stats[b].GD) {
    return stats[b].GD - stats[a].GD;
  }
  // 5. Goals for
  if (stats[a].GF !== stats[b].GF) {
    return stats[b].GF - stats[a].GF;
  }
  // 6. Alphabetical order
  return 0;
}

/**
 * Compute the points of teamA against teamB in head‑to‑head matches.
 * Points follow same rules: normal win = 3, penalty win = 2, penalty loss = 1, normal loss = 0.
 *
 * @param {number} teamA index
 * @param {number} teamB index
 * @param {Array} matches
 * @returns {number}
 */
function getHeadToHeadPoints(teamA, teamB, matches) {
  let points = 0;
  matches.forEach((m) => {
    if (m.homeGoals === null || m.awayGoals === null) return;
    const isAB = (m.homeTeam === teamA && m.awayTeam === teamB);
    const isBA = (m.homeTeam === teamB && m.awayTeam === teamA);
    if (!isAB && !isBA) return;
    const hg = m.homeGoals;
    const ag = m.awayGoals;
    if (hg > ag) {
      // Home team wins normal
      if (m.homeTeam === teamA) points += 3;
      // Away team gets nothing
    } else if (hg < ag) {
      if (m.awayTeam === teamA) points += 3;
    } else {
      // Draw; penalty winner
      if (m.penaltyWinner === teamA) {
        points += 2;
      } else if (m.penaltyWinner === teamB) {
        // teamA loses on penalties
        points += 1;
      }
    }
  });
  return points;
}

/**
 * Compute head‑to‑head goal difference (GF - GA) of teamA against teamB.
 * Only normal time goals count.
 * @param {number} teamA
 * @param {number} teamB
 * @param {Array} matches
 * @returns {number}
 */
function getHeadToHeadGoalDiff(teamA, teamB, matches) {
  let gf = 0;
  let ga = 0;
  matches.forEach((m) => {
    if (m.homeGoals === null || m.awayGoals === null) return;
    const isAB = (m.homeTeam === teamA && m.awayTeam === teamB);
    const isBA = (m.homeTeam === teamB && m.awayTeam === teamA);
    if (!isAB && !isBA) return;
    if (m.homeTeam === teamA && m.awayTeam === teamB) {
      gf += m.homeGoals;
      ga += m.awayGoals;
    } else if (m.homeTeam === teamB && m.awayTeam === teamA) {
      gf += m.awayGoals;
      ga += m.homeGoals;
    }
  });
  return gf - ga;
}